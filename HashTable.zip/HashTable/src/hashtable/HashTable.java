/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtable;
import java.util.Random;
/**
 *
 * @author hp
 */
public class HashTable {
    
    //Creating an array list 
   static int[] array = {10,2,5,9,3,1,8,4,12,7,6,11};
   
   
public static void main(String[] args) {
    
    //Creatin g a new instance of the class MyHashTable.
		MyHashTable hashTable = new MyHashTable();

   
		
               
	
        // Printing the elements of the list before hashing  
         System.out.println("Array list elements:");
         for(int x=0; x<array.length;x++){
             System.out.print(array[x]+"  ");
         }
         System.out.print("\n");
         
        // Printing the elements of the list orderly after hashing  
         for(int i=0;i<array.length; i++){
         hashTable.put(array[i]);
         }
         hashTable.print();
         
         
	}
   

public static class MyHashTable {
	
	private static final int totalSize = array.length+1;
	private Integer[] data;
	private int capacity;
	private int size;
	
	public MyHashTable() {
		this(totalSize);
	}
	
        private void init() {
		data = new Integer[capacity];
		size = 0;
	}
        
	public MyHashTable(int capacity) {
		this.capacity = capacity;
		init();
	}
	
	
	// Function that operates the hash function and return the hash value
	private int hashFunction(int element) {
		int hashValue = element%capacity;
		
		return hashValue;
	}
	// Function that adds an integer into the array list
        public boolean put(int element) {
		
		data[hashFunction(element)] = new Integer(element);
		size++;
		
		return true;
	}
	
	// Function that returns an empty size 
	public boolean isEmpty() {
		return size == 0;
	}
	
        // Function to print out the element in order
	public void print() {
		System.out.println("Hash Table: ");
		if(isEmpty()) {
			System.out.print("Empty");
		} else {
                       
			for(int i = 0; i < capacity; i++) {
				if(data[i] != null) {
					System.out.print( data[i]+"  ");
				}
			}
		}
		System.out.print("\n");
	}
	
	
	
}

    
}
